name = "Hacker"

print(name)

