for n in range(0,20):
    print(n)
