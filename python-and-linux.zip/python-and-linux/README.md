# Python-Linux
 Variables, Operations And Basic Commands On Python

 ![01](print-commands-linux-ubuntu-01.png)
 ![02](print-commands-linux-ubuntu-02.png)
 ![03](print-commands-linux-ubuntu-03.png)
 ![04](print-commands-linux-ubuntu-04.png)
 ![05](print-commands-linux-ubuntu-05.png)
 ![06](print-commands-linux-ubuntu-06.png)


