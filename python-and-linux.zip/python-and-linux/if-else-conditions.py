name = input("Name: ")
password = input("Password: ")

if name == "HackerX" and password == "xxx":
    print("Welcome, ", name)
elif name == "HackerY" and password == "yyy":
    print("Welcome, ", name)
else:
    print("Access Denied!")
