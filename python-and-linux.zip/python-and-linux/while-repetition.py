numero = 1

while numero <= 10:
    print(numero)
    numero = numero + 1
