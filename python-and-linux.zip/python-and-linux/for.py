list =  ['HackerX', 'HackerWeb']

#print(list)
for i in list:
    print(i)
