#name = "Jonathan"
#age = "24"
#numero = "121" // It is a text
#numero = 121 // It is a number

number1 = 20
number2 = 20
number3 = 15

total = number1 + number2 + number3 + 5

    print(total + 40)
#print(total + 40)

